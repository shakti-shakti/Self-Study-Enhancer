"use client";
import React, { useRef } from 'react';

export default function NcertViewerPage() {
  // Your component code here
  return (
    <div>Ncert Viewer Page Content</div>
  );
}
